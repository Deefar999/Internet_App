import React from 'react';
import RecipeSearch from './RecipeSearch';

const App = () => {
  return (
    <div className="App">
      <RecipeSearch />
    </div>
  );
}

export default App;
